# pil_meta/loaders/config_loader.py
"""
Config Loader (loaders)

Loads and validates the pilconfig.json configuration file for the PIL project.
"""

import json
from pathlib import Path

def load_config(config_path: str) -> dict:
    """
    Load the PIL project configuration from pilconfig.json.

    Args:
        config_path (str): Path to pilconfig.json file (absolute or relative)

    Returns:
        dict: Configuration fields as a dictionary.
    """
    config_file = Path(config_path)
    if not config_file.exists():
        raise FileNotFoundError(f"Config file not found: {config_path}")
    with open(config_file, "r", encoding="utf-8") as f:
        config = json.load(f)
    # Optionally validate required fields
    required = ["project_root", "output_dir"]
    missing = [k for k in required if k not in config]
    if missing:
        raise ValueError(f"Missing required config fields: {missing}")
    return config

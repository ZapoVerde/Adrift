# fileB_func (in mod)
> **Fully qualified name:** `mod.fileB_func`

**Type:** function
**Module:** mod
**Status:** active
**Visibility:** public
**Tags:** #fileB
**Deprecated:** ❌

---

## Description
Function B uses shared_constant.

## Full Docstring
```
Function B docstring.
```

## Links
- **uses**: mod.shared_constant


---

# fileA_func (in mod)
> **Fully qualified name:** `mod.fileA_func`

**Type:** function
**Module:** mod
**Status:** active
**Visibility:** public
**Tags:** #fileA
**Deprecated:** ❌

---

## Description
Function A uses shared_constant.

## Full Docstring
```
Function A docstring.
```

## Links
- **uses**: mod.shared_constant


---

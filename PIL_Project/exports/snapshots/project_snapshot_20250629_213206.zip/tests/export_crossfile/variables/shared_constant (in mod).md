# shared_constant (in mod)
> **Fully qualified name:** `mod.shared_constant`

**Type:** variable
**Module:** mod
**Status:** active
**Visibility:** public
**Tags:** #shared
**Deprecated:** ❌

---

## Description
A constant used in multiple places.

## Full Docstring
```
Shared constant for cross-file test.
```

## Links
None

---

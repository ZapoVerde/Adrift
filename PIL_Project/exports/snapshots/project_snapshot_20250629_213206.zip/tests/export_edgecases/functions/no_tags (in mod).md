# no_tags (in mod)
> **Fully qualified name:** `mod.no_tags`

**Type:** function
**Module:** mod
**Status:** active
**Visibility:** public
**Tags:** 
**Deprecated:** ❌

---

## Description
No tags here.

## Full Docstring
```
Should export without #tags.
```

## Links
None

---

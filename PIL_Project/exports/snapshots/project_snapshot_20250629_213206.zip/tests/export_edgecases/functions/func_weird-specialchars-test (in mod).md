# func/weird:special*chars|test? (in mod)
> **Fully qualified name:** `mod.func/weird:special*chars|test?`

**Type:** function
**Module:** mod
**Status:** active
**Visibility:** public
**Tags:** #special #chars
**Deprecated:** ❌

---

## Description
Contains special filesystem chars.

## Full Docstring
```
Special char test docstring.
```

## Links
None

---

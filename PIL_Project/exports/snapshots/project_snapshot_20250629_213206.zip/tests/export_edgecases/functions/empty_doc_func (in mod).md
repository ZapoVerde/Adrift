# empty_doc_func (in mod)
> **Fully qualified name:** `mod.empty_doc_func`

**Type:** function
**Module:** mod
**Status:** active
**Visibility:** public
**Tags:** #sample
**Deprecated:** ❌

---

## Description


## Full Docstring
```

```

## Links
None

---

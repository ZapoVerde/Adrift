# old_func (in mod)
> **Fully qualified name:** `mod.old_func`

**Type:** function
**Module:** mod
**Status:** inactive
**Visibility:** private
**Tags:** #deprecated
**Deprecated:** ✅

---

## Description
Deprecated function.

## Full Docstring
```
Old deprecated function.
```

## Links
None

---

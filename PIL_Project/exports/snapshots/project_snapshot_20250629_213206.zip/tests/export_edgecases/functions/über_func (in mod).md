# über_func (in mod)
> **Fully qualified name:** `mod.über_func`

**Type:** function
**Module:** mod
**Status:** active
**Visibility:** public
**Tags:** #unicodé
**Deprecated:** ❌

---

## Description
Handles ünicode correctly.

## Full Docstring
```
Ünicode test docstring.
```

## Links
None

---

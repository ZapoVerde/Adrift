# scripts/snapshot_project.py

import os
import zipfile
from datetime import datetime
from pathlib import Path
import json
import sys

IGNORED_FOLDERS = {
    '.git', '__pycache__', 'node_modules', 'snapshots', 'exports', '.mypy_cache', '.venv', 'env', '.idea'
}

def snapshot_project(src_dir, snapshot_dir, entity_graph_path=None):
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    snapshot_name = f"project_snapshot_{ts}.zip"
    snapshot_path = Path(snapshot_dir) / snapshot_name

    print(f"[INFO] Source dir: {src_dir} (exists: {os.path.exists(src_dir)})")
    print(f"[INFO] Saving snapshot to: {snapshot_path}")

    with zipfile.ZipFile(snapshot_path, "w", zipfile.ZIP_DEFLATED, allowZip64=True) as zipf:
        file_count = 0
        for foldername, subfolders, filenames in os.walk(src_dir):
            rel_folder = os.path.relpath(foldername, src_dir)
            if any(part in IGNORED_FOLDERS for part in rel_folder.split(os.sep)):
                continue
            for filename in filenames:
                filepath = Path(foldername) / filename
                arcname = filepath.relative_to(src_dir)
                try:
                    zipf.write(filepath, arcname)
                    file_count += 1
                    if file_count % 100 == 0:
                        print(f"  Zipped {file_count} files so far...")
                except Exception as e:
                    print(f"  [SKIP] {filepath}: {e}", file=sys.stderr)
        # Add the entity_graph.json file explicitly, if provided
        if entity_graph_path and os.path.exists(entity_graph_path):
            arcname = "exports/entity_graph.json"
            zipf.write(entity_graph_path, arcname)
            print(f"  Included {entity_graph_path} as {arcname} in snapshot.")
    print(f"✅ Snapshot saved: {snapshot_path} ({file_count} files + entity graph archived)")

if __name__ == "__main__":
    try:
        with open("pilconfig.json", "r", encoding="utf-8") as f:
            config = json.load(f)
        src_dir = config["project_root"]
        snapshot_dir = config.get("snapshot_dir", "./exports/snapshots/")
        entity_graph_path = os.path.join("exports", "entity_graph.json")
        Path(snapshot_dir).mkdir(parents=True, exist_ok=True)
        snapshot_project(src_dir, snapshot_dir, entity_graph_path)
    except Exception as ex:
        print(f"[ERROR] {ex}", file=sys.stderr)
        sys.exit(1)

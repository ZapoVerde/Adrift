# Design Journal

## 🔒 Governance Rules (Excerpt)

- All changes affecting code structure or design rationale must be logged in `/docs/changelog_combined.md`.
- The assistant will prompt for a changelog entry unless waived.
- Change entries must include both a narrative (why) and delta (what).

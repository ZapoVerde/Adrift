# ParetoDebug
a debugger designed to feed an AI

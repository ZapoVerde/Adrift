# exploration_flow.py
# Handles travel and room transitions.

def resolve_room_entry(player, room):
    """
    Placeholder for resolving the effects of entering a new room.

    @ignore: stub — travel entry logic not yet implemented
    """
    pass

def handle_travel_command(command):
    """
    Placeholder for processing a travel command.

    @ignore: stub — movement input handling deferred
    """
    pass
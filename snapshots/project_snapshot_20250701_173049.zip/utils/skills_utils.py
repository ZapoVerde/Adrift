# skills_utils.py
# General skill access and progression utilities.

def tick_skill_progression(actor):
    """
    Placeholder for advancing passive skill timers.

    @ignore: stub — time-based skill gains not implemented
    """
    pass

def get_skill_modifier(actor, skill_id):
    """
    Placeholder for computing stat bonus from skill.

    @ignore: stub — no lookup logic wired
    """
    pass

def add_skill_xp(actor, skill_id, xp):
    """
    Placeholder for incrementing raw skill XP.

    @ignore: stub — skill injection not functional
    """
    pass
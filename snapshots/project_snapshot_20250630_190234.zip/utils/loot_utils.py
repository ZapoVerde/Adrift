# loot_utils.py
# Loot generation and drop placement.

def roll_loot_table(table_id):
    """
    Placeholder for rolling entries from a loot table.

    @ignore: stub — no loot system yet
    """
    pass

def drop_loot_to_room(room, items):
    """
    Placeholder for distributing loot into a tactical room.

    @ignore: stub — item placement logic missing
    """
    pass

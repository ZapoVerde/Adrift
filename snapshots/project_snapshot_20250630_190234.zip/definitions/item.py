# item.py
# Basic item structure.

class Item:
    """
    Placeholder class for equippable and interactable items.

    @ignore: stub — item system not yet implemented
    """
    def __init__(self):
        pass
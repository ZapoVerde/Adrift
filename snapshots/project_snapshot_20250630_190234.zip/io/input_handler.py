# input_handler.py
# Parses and routes player commands

def get_player_input():
    """
    Placeholder for reading player input.

    @ignore: stub — no player input system yet
    """
    pass

def parse_command(raw_input):
    """
    Placeholder for converting raw input into structured command dict.

    @ignore: stub — parser not implemented
    """
    pass
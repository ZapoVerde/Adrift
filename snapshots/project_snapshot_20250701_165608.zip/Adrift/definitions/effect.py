# effect.py
# Status effect definition.

class Effect:
    """
    Placeholder class for status effects and conditions.

    @ignore: stub — no effect logic implemented
    """
    def __init__(self):
        pass

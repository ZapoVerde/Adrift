# combat_utils.py
# Combat resolution.

def resolve_attack(attacker, target): pass

def calculate_damage(weapon, attacker, target): pass

def roll_hit(attacker, target): pass


# npc_ai.py
# Handles basic enemy decision making.

def handle_npc_action(npc):
    """
    Placeholder for executing a turn for an NPC.

    @ignore: stub — AI loop not implemented
    """
    pass

def choose_npc_action(npc):
    """
    Placeholder for selecting an NPC action.

    @ignore: stub — decision logic deferred
    """
    pass

def npc_can_see_player(npc, player):
    """
    Placeholder for visibility logic between NPC and player.

    @ignore: stub — perception loop missing
    """
    pass

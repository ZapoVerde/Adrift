# unknown (in mod)
> **Fully qualified name:** `mod.SampleClass`

**Type:** class
**Module:** mod
**Status:** active
**Visibility:** public
**Tags:** #class #test
**Deprecated:** ❌

---

## Description
Class with links.

## Full Docstring
```
Class docstring.
```

## Links
- **calls**: mod.empty_doc_func
- **related_to**: mod.über_func
- **journal**: journal_entry_002


---
